<?php

/**
 * UnsupportedCurveException
 *
 * PHP version 5
 *
 * @author    Jim Wigginton <terrafrost@php.net>
 * @copyright 2015 Jim Wigginton
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://phpseclib.sourceforge.net
 */
namespace Mihdan\IndexNow\Dependencies\phpseclib3\Exception;

/**
 * UnsupportedCurveException
 *
 * @author  Jim Wigginton <terrafrost@php.net>
 * @internal
 */
class UnsupportedCurveException extends \RuntimeException
{
}
