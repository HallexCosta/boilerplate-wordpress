<?php

/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
namespace ahrefs\AhrefsSeo_Vendor\Google\Service\AnalyticsReporting;

class MetricFilter extends \ahrefs\AhrefsSeo_Vendor\Google\Model
{
    /**
     * @var string
     */
    public $comparisonValue;
    /**
     * @var string
     */
    public $metricName;
    /**
     * @var bool
     */
    public $not;
    /**
     * @var string
     */
    public $operator;
    /**
     * @param string
     */
    public function setComparisonValue($comparisonValue)
    {
        $this->comparisonValue = $comparisonValue;
    }
    /**
     * @return string
     */
    public function getComparisonValue()
    {
        return $this->comparisonValue;
    }
    /**
     * @param string
     */
    public function setMetricName($metricName)
    {
        $this->metricName = $metricName;
    }
    /**
     * @return string
     */
    public function getMetricName()
    {
        return $this->metricName;
    }
    /**
     * @param bool
     */
    public function setNot($not)
    {
        $this->not = $not;
    }
    /**
     * @return bool
     */
    public function getNot()
    {
        return $this->not;
    }
    /**
     * @param string
     */
    public function setOperator($operator)
    {
        $this->operator = $operator;
    }
    /**
     * @return string
     */
    public function getOperator()
    {
        return $this->operator;
    }
}
// Adding a class alias for backwards compatibility with the previous class name.
\class_alias(\ahrefs\AhrefsSeo_Vendor\Google\Service\AnalyticsReporting\MetricFilter::class, 'ahrefs\\AhrefsSeo_Vendor\\Google_Service_AnalyticsReporting_MetricFilter');
