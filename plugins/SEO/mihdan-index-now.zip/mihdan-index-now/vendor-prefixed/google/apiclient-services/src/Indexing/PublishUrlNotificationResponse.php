<?php

/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
namespace Mihdan\IndexNow\Dependencies\Google\Service\Indexing;

/** @internal */
class PublishUrlNotificationResponse extends \Mihdan\IndexNow\Dependencies\Google\Model
{
    protected $urlNotificationMetadataType = UrlNotificationMetadata::class;
    protected $urlNotificationMetadataDataType = '';
    /**
     * @param UrlNotificationMetadata
     */
    public function setUrlNotificationMetadata(UrlNotificationMetadata $urlNotificationMetadata)
    {
        $this->urlNotificationMetadata = $urlNotificationMetadata;
    }
    /**
     * @return UrlNotificationMetadata
     */
    public function getUrlNotificationMetadata()
    {
        return $this->urlNotificationMetadata;
    }
}
// Adding a class alias for backwards compatibility with the previous class name.
\class_alias(PublishUrlNotificationResponse::class, 'Mihdan\\IndexNow\\Dependencies\\Google_Service_Indexing_PublishUrlNotificationResponse');
